
<script src="assets/library/jquery-3.1.1.js"> </script>
<script src="assets/bootstrap-4.2.1-dist/js/bootstrap.js"> </script>

