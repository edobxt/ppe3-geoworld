<hr />
<footer class="footer mt-auto py-3">
  <div class="container">
    <span class="text-muted">SIO SLAM MyWebApp &copy; 2019</span>
  </div>
</footer>

  </body>
</html>
