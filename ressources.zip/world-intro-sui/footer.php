    <hr />
    <footer style="padding-bottom: 2em">
      <div style="text-align: center">MyWebApp &copy; 2018</div>
     </footer>

  </body>
</html>
